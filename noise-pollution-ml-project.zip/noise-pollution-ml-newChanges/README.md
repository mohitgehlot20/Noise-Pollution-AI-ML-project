# Noise Pollution Analysis

- Install conda on the machine
- Use below command to create environment
    > $ conda create --name <env> --file requirements.txt